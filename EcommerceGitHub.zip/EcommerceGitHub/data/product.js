const products = [
  {
    id: 1,
    name: "Apple iPhone 14 Pro",
    description: "6.1-inch Super Retina XDR display with ProMotion",
    price: 1299.99,
    category: "Electronics"
  },
  {
    id: 2,
    name: "Nike Air Max",
    description: "Comfortable running shoes",
    price: 199.99,
    category: "Apparel"
  },
  {
    id: 3,
    name: "Levi's Jeans",
    description: "Slim fit denim jeans",
    price: 59.99,
    category: "Apparel"
  }
];

module.exports = products;

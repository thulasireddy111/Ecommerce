// src/routes/productRoutes.js

const express = require('express');
const router = express.Router();
const products = require('../data/product');

// GET /api/products — list all products or filter by category
router.get('/', (req, res) => {
  const category = req.query.category;

  if (category) {
    const filtered = products.filter(product =>
      product.category.toLowerCase() === category.toLowerCase()
    );
    return res.json(filtered);
  }

  res.json(products);
});

// GET /api/products/:id — get product by ID
router.get('/:id', (req, res) => {
  const productId = parseInt(req.params.id);
  const product = products.find(p => p.id === productId);

  if (!product) {
    return res.status(404).json({ message: 'Product not found' });
  }

  res.json(product);
});

// POST /api/products — add new product (optional, for testing)
router.post('/', (req, res) => {
  const { name, category, price } = req.body;

  if (!name || !category || !price) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  const newProduct = {
    id: products.length + 1,
    name,
    category,
    price
  };

  products.push(newProduct);
  res.status(201).json(newProduct);
});

module.exports = router;
